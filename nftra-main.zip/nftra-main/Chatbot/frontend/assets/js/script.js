document.addEventListener("DOMContentLoaded", () => {
    const chatBox = document.getElementById("chat-box");
    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");
    const statusIndicator = document.querySelector('.status-indicator');

    // Initialize status check
    checkStatus();
    setInterval(checkStatus, 30000);

    async function checkStatus() {
        try {
            const response = await fetch('/status');
            if (response.ok) {
                statusIndicator.innerHTML = `
                    <div class="status-dot connected"></div>
                    <span class="status-text">Connected</span>
                `;
            }
        } catch (error) {
            statusIndicator.innerHTML = `
                <div class="status-dot"></div>
                <span class="status-text">Connection Error</span>
            `;
        }
    }

    sendButton.addEventListener("click", sendMessage);
    userInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    function showLoading() {
        const spinner = document.createElement('div');
        spinner.className = 'loading-spinner';
        spinner.innerHTML = `
            <div class="sand-clock"></div>
            <div class="loading-text">Analyzing Impact...</div>
        `;
        chatBox.appendChild(spinner);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;

        appendMessage(message, "user");
        userInput.value = "";
        showLoading();

        try {
            const response = await fetch("http://127.0.0.1:5000/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message }),
            });

            const data = await response.json();
            document.querySelector('.loading-spinner')?.remove();

            if (data.error) {
                appendMessage(`Error: ${data.error}`, "bot");
            } else {
                const formattedResponse = `
                    <strong>Risk Level:</strong> ${data.response.risk}<br>
                    <strong>Recommended Tests:</strong> ${data.response.tests.join(', ')}<br>
                    <strong>Analysis:</strong> ${data.response.reason}
                `;
                appendMessage(formattedResponse, "bot");
            }
        } catch (error) {
            document.querySelector('.loading-spinner')?.remove();
            appendMessage(`Error: ${error.message}`, "bot");
        }
    }

    function appendMessage(content, sender) {
        const timestamp = new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });

        const messageElement = document.createElement('div');
        messageElement.classList.add('message', `${sender}-message`);
        messageElement.innerHTML = `
            <div class="message-header">
                <span class="message-sender">${sender === 'user' ? 'You' : 'Performance Bot'}</span>
                <span class="message-time">${timestamp}</span>
            </div>
            <div class="message-content">${sender === 'bot' ? DOMPurify.sanitize(content) : content}</div>
        `;

        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
});