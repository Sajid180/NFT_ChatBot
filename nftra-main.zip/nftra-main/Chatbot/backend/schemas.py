RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {
        "risk": {"type": "string", "enum": ["High", "Medium", "Low"]},
        "tests": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1
        },
        "reason": {"type": "string", "minLength": 50}
    },
    "required": ["risk", "tests", "reason"],
    "additionalProperties": False
}