from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv
from openai import OpenAI
import json
import logging
from jsonschema import validate, ValidationError
from schemas import RESPONSE_SCHEMA

# Initialize environment
load_dotenv()
client = OpenAI()

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

app = Flask(__name__, static_folder="../frontend", static_url_path="/frontend")
CORS(app, resources={r"/*": {"origins": "http://localhost:5000"}})

SYSTEM_PROMPT = """
You are a performance engineering expert. Analyze user input and provide:
1. Risk assessment (High/Medium/Low)
2. Recommended performance tests
3. Technical reasoning

Respond in JSON format:
{
    "risk": "Risk level",
    "tests": ["Test1", "Test2"],
    "reason": "Technical explanation"
}
"""

@app.route("/")
def serve_index():
    return send_from_directory("../frontend", "index.html")

@app.route("/status")
def status_check():
    return jsonify({
        "status": "operational",
        "version": "2.0.1",
        "services": {
            "openai": "connected",
            "database": "active"
        }
    }), 200

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "Invalid request format"}), 400

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": data["message"]}
        ]

        try:
            response = client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                temperature=0.7,
                max_tokens=500
            )
            
            result = json.loads(response.choices[0].message.content)
            validate(instance=result, schema=RESPONSE_SCHEMA)
            
            return jsonify({"response": result})
            
        except ValidationError as ve:
            logging.error(f"Validation error: {str(ve)}")
            return jsonify({"error": "Invalid AI response format"}), 500
            
        except Exception as e:
            logging.error(f"AI processing error: {str(e)}")
            return jsonify({"error": "Failed to process request"}), 500

    except Exception as e:
        logging.critical(f"Server error: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(debug=False, port=5000)