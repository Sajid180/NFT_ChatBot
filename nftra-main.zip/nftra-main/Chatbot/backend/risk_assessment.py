def assess_performance_impact(changes):
    """
    Assess performance impact using predefined rules.
    """
    results = []
    for change in changes:
        risk = "Medium"
        tests = ["Load Testing", "Soak Testing"]
        reason = "Based on the provided change, medium risk is assessed. Load and soak testing are recommended."
        results.append({
            "change": change,
            "risk": risk,
            "tests": tests,
            "reason": reason,
        })
    return {"results": results}
